// 회귀(NewGame+) 메타 영속화 + 액션.
//
// 캐릭터 세이브(ninthinning.save.v1)와 독립된 별도 localStorage 키에
// 영구 누적 데이터를 저장한다. 캐릭터 리셋/삭제와 무관하게 보존되어야 한다.
//
// 점수 산정: hallOfFame.computeHallOfFameScore 의 total 을 그대로 사용 — 은퇴 시
// recordRun(score) 호출이 balance / totalEarned / runs 를 업데이트.
//
// 영구 / 재구매 분류:
//   permanentPurchases  : 재능 슬롯, stage cap (영구 누적)
//   unlockedItems       : 도전과제 키 (영구)
//   loadout             : 다음 캐릭터에 적용될 1회용 선택 (시작능력치/특성/유물)
//                          → 캐릭터 생성 시 read, 생성 직후 reset

import { state } from "../state.js";
import { computeHallOfFameScore, hofRank } from "./hallOfFame.js";
import {
  TALENT_SLOTS_TIERS, STAT_KEYS, STAT_CAP_STEP, statCapCost,
  STARTING_STAT_PRESETS, TRAITS, RELICS, isTraitUnlocked, relicCost,
  EQUIPMENT_CATALOG, getEquipmentSpec,
} from "../data/shopCatalog.js";

export const REGRESSION_KEY = "ninthinning.regression.v1";

// 기본 스키마. 새 사용자/로드 실패 시 모두 이 값으로 시작.
export function defaultRegressionMeta() {
  return {
    balance: 0,
    totalEarned: 0,
    runs: 0,
    permanentPurchases: {
      talentSlots: 0,                              // 0~2 (추가 슬롯 수. 총 1+N 재능)
      statCaps: {},                                // 스탯별 +5 캡 구매 횟수 { contact:N, ... } — 전 stage 공통
      ownedTraits: [],                              // 영구 소유 trait 키 — 장착/해제와 무관, 한 번 사면 보존
      ownedRelics: [],                              // 영구 소유 relic 키 (relicLevels 와 동기 — 키 존재 = 보유)
      relicLevels: {},                              // 유물 레벨 { relicKey: level(>=1) } — 재구매 시 +1, 효과 점증
      equipment: { bat: 0, glove: 0, cleats: 0 },   // 영구 소유 장비 레벨 (0~3)
    },
    unlockedItems: [],                              // 도전과제 해금 키
    loadout: {
      startingStat: null,                           // "balanced" | "battingFocus" | "pitchingFocus"
      traits: [],                                   // 최대 3 — 장착 trait 키
      relics: [],                                   // 최대 2 — 장착 relic 키
      equipment: { bat: 0, glove: 0, cleats: 0 },   // 장착 장비 상태
    },
    hallOfFameMuseum: {
      batter: null,
      pitcher: null,
      balanced: null,
      honor: null,
      tournament: null,
    },
  };
}

// 일부 필드 누락된 옛 메타를 현재 스키마로 끌어올림. 향후 v2 마이그레이션 hook 의 자리.
function migrateMeta(data) {
  const base = defaultRegressionMeta();
  const out = { ...base, ...(data ?? {}) };
  out.permanentPurchases = { ...base.permanentPurchases, ...(data?.permanentPurchases ?? {}) };
  // 스탯별 캡 — 옛 그룹형(capBoosts {amateur,kbo,mlb})은 스키마가 달라 폐기, statCaps 만 승계.
  out.permanentPurchases.statCaps = { ...(data?.permanentPurchases?.statCaps ?? {}) };
  delete out.permanentPurchases.capBoosts;
  out.permanentPurchases.ownedTraits = Array.isArray(data?.permanentPurchases?.ownedTraits)
    ? [...data.permanentPurchases.ownedTraits] : [];
  out.permanentPurchases.ownedRelics = Array.isArray(data?.permanentPurchases?.ownedRelics)
    ? [...data.permanentPurchases.ownedRelics] : [];
  
  // 장비 스키마 승계 / 초기화
  out.permanentPurchases.equipment = {
    ...base.permanentPurchases.equipment,
    ...(data?.permanentPurchases?.equipment ?? {})
  };

  out.unlockedItems = Array.isArray(data?.unlockedItems) ? [...data.unlockedItems] : [];
  out.loadout = { ...base.loadout, ...(data?.loadout ?? {}) };
  out.loadout.traits = Array.isArray(data?.loadout?.traits) ? [...data.loadout.traits] : [];
  out.loadout.relics = Array.isArray(data?.loadout?.relics) ? [...data.loadout.relics] : [];
  out.loadout.equipment = { ...base.loadout.equipment, ...(data?.loadout?.equipment ?? {}) };
  
  out.hallOfFameMuseum = {
    ...base.hallOfFameMuseum,
    ...(data?.hallOfFameMuseum ?? {})
  };


  // 옛 세이브 자동 승계 — 이미 장착되어 있던 trait/relic 은 영구 소유로 간주.
  for (const k of out.loadout.traits) {
    if (!out.permanentPurchases.ownedTraits.includes(k)) out.permanentPurchases.ownedTraits.push(k);
  }
  for (const k of out.loadout.relics) {
    if (!out.permanentPurchases.ownedRelics.includes(k)) out.permanentPurchases.ownedRelics.push(k);
  }
  // 유물 레벨 — 누락(옛 세이브) 시 보유 유물을 Lv.1 로 초기화.
  out.permanentPurchases.relicLevels = { ...(data?.permanentPurchases?.relicLevels ?? {}) };
  for (const k of out.permanentPurchases.ownedRelics) {
    if (!(out.permanentPurchases.relicLevels[k] >= 1)) out.permanentPurchases.relicLevels[k] = 1;
  }
  return out;
}

export function loadRegressionMeta() {
  try {
    const raw = localStorage.getItem(REGRESSION_KEY);
    if (!raw) {
      state.regression = defaultRegressionMeta();
      return state.regression;
    }
    state.regression = migrateMeta(JSON.parse(raw));
    return state.regression;
  } catch (e) {
    console.error("regression load failed", e);
    state.regression = defaultRegressionMeta();
    return state.regression;
  }
}

export function saveRegressionMeta() {
  try {
    if (!state.regression) state.regression = defaultRegressionMeta();
    localStorage.setItem(REGRESSION_KEY, JSON.stringify(state.regression));
    return true;
  } catch (e) {
    console.error("regression save failed", e);
    return false;
  }

}

function ensureMeta() {
  if (!state.regression) state.regression = defaultRegressionMeta();
  return state.regression;
}

// ── 잔액 조작 ──────────────────────────────────────────────────────
export function addBalance(amount) {
  if (!Number.isFinite(amount) || amount <= 0) return 0;
  const m = ensureMeta();
  m.balance += amount;
  m.totalEarned += amount;
  saveRegressionMeta();
  return m.balance;
}

// 차감 가능하면 차감 후 true, 부족하면 false (잔액 무변경).
export function spendBalance(amount) {
  if (!Number.isFinite(amount) || amount <= 0) return false;
  const m = ensureMeta();
  if (m.balance < amount) return false;
  m.balance -= amount;
  saveRegressionMeta();
  return true;
}

// 회귀 1회 기록 — 은퇴 시 HoF 점수를 balance/totalEarned 에 추가하고 runs++.
export function recordRun(score) {
  const m = ensureMeta();
  m.runs += 1;
  if (Number.isFinite(score) && score > 0) {
    m.balance += score;
    m.totalEarned += score;
  }
  saveRegressionMeta();
  return m;
}

// ── 영구 구매 ──────────────────────────────────────────────────────
// kind: "talentSlots" | "capBoost"
// talentSlots: payload 없음 — 다음 tier 자동 구매
// capBoost:    payload = { stat: "contact"|...|"mental" } — 해당 스탯 캡 +5 (상한 없음, 가격 점증)
// 성공 시 { ok: true, ... }, 실패 시 { ok: false, reason: "..." }.
export function purchasePermanent(kind, payload = {}) {
  const m = ensureMeta();
  if (kind === "talentSlots") {
    const current = m.permanentPurchases.talentSlots;
    const next = TALENT_SLOTS_TIERS[current];   // 0 이면 첫 tier (totalSlots:2), 1 이면 두 번째 (totalSlots:3)
    if (!next) return { ok: false, reason: "max_tier" };
    if (m.balance < next.cost) return { ok: false, reason: "insufficient_balance" };
    m.balance -= next.cost;
    m.permanentPurchases.talentSlots = current + 1;
    saveRegressionMeta();
    return { ok: true, kind, tier: next.tier, cost: next.cost, totalSlots: next.totalSlots };
  }
  if (kind === "capBoost") {
    const stat = payload.stat;
    if (!STAT_KEYS.includes(stat)) return { ok: false, reason: "invalid_stat" };
    if (!m.permanentPurchases.statCaps) m.permanentPurchases.statCaps = {};
    const owned = m.permanentPurchases.statCaps[stat] ?? 0;
    const cost = statCapCost(owned);
    if (m.balance < cost) return { ok: false, reason: "insufficient_balance" };
    m.balance -= cost;
    m.permanentPurchases.statCaps[stat] = owned + 1;
    saveRegressionMeta();
    return { ok: true, kind, stat, cost, add: STAT_CAP_STEP, owned: owned + 1 };
  }
  return { ok: false, reason: "unknown_kind" };
}

// ── 도전과제 해금 ─────────────────────────────────────────────────
// 중복 방지. 신규 해금 시 true, 이미 해금된 키면 false.
export function unlockItem(key) {
  if (!key) return false;
  const m = ensureMeta();
  if (m.unlockedItems.includes(key)) return false;
  m.unlockedItems.push(key);
  saveRegressionMeta();
  return true;
}

// ── 로드아웃 ──────────────────────────────────────────────────────
// 캐릭터 생성 직전 사용자가 상점에서 고른 1회용 선택 — startingStat / traits / relics.
// 캐릭터 생성 시 read 한 뒤 즉시 resetLoadout() 호출 (캐릭터당 1회 효과).
export function setStartingStat(presetKey) {
  const m = ensureMeta();
  if (presetKey !== null && !STARTING_STAT_PRESETS[presetKey]) return false;
  m.loadout.startingStat = presetKey;
  saveRegressionMeta();
  return true;
}

// 장착만 담당 — 포인트 차감 없음. 이미 소유한(ownedTraits) 항목만 장착 가능.
export function setTraits(traitKeys) {
  const m = ensureMeta();
  if (!Array.isArray(traitKeys)) return false;
  if (traitKeys.length > 3) return false;
  for (const k of traitKeys) {
    if (!TRAITS[k]) return false;
    if (!isTraitUnlocked(k, m.unlockedItems)) return false;
    if (!m.permanentPurchases.ownedTraits.includes(k)) return false;
  }
  m.loadout.traits = [...traitKeys];
  saveRegressionMeta();
  return true;
}

// 장착만 담당 — 포인트 차감 없음. 이미 소유한(ownedRelics) 항목만 장착 가능.
export function setRelics(relicKeys) {
  const m = ensureMeta();
  if (!Array.isArray(relicKeys)) return false;
  if (relicKeys.length > 2) return false;
  for (const k of relicKeys) {
    if (!RELICS[k]) return false;
    if (!m.permanentPurchases.ownedRelics.includes(k)) return false;
  }
  m.loadout.relics = [...relicKeys];
  saveRegressionMeta();
  return true;
}

// trait 구매 — 미소유시 비용 차감 + ownedTraits 등록. 소유 중이면 no-op.
export function purchaseTrait(key) {
  const m = ensureMeta();
  if (!TRAITS[key]) return { ok: false, reason: "invalid" };
  if (!isTraitUnlocked(key, m.unlockedItems)) return { ok: false, reason: "locked" };
  if (m.permanentPurchases.ownedTraits.includes(key)) return { ok: false, reason: "owned" };
  const cost = TRAITS[key].cost;
  if (m.balance < cost) return { ok: false, reason: "insufficient_balance" };
  m.balance -= cost;
  m.permanentPurchases.ownedTraits.push(key);
  saveRegressionMeta();
  return { ok: true, key, cost };
}

// relic 구매 — 미소유시 비용 차감 + ownedRelics 등록. 소유 중이면 no-op.
// 유물 구매 — 첫 구매는 Lv.1 보유, 재구매 시 레벨업(효과·가격 점증, 상한 없음).
export function purchaseRelic(key) {
  const m = ensureMeta();
  if (!RELICS[key]) return { ok: false, reason: "invalid" };
  if (!m.permanentPurchases.relicLevels) m.permanentPurchases.relicLevels = {};
  const curLevel = m.permanentPurchases.relicLevels[key] ?? 0;
  const cost = relicCost(key, curLevel);
  if (m.balance < cost) return { ok: false, reason: "insufficient_balance" };
  m.balance -= cost;
  const wasNew = curLevel === 0;
  m.permanentPurchases.relicLevels[key] = curLevel + 1;
  if (!m.permanentPurchases.ownedRelics.includes(key)) m.permanentPurchases.ownedRelics.push(key);
  // 최초 구매 유물은 빈 슬롯이 있으면 자동 장착 (최대 2개). 모든 구매 경로에서 일관 적용.
  let equipped = false;
  if (wasNew && m.loadout.relics.length < 2 && !m.loadout.relics.includes(key)) {
    m.loadout.relics.push(key);
    equipped = true;
  }
  saveRegressionMeta();
  return { ok: true, key, cost, level: curLevel + 1, equipped };
}

export function resetLoadout() {
  const m = ensureMeta();
  m.loadout = { startingStat: null, traits: [], relics: [], equipment: { bat: 0, glove: 0, cleats: 0 } };
  saveRegressionMeta();
}

// 캐릭터 생성 직전 호출 — 현재 loadout snapshot 을 반환.
// 장비/유물/특성은 장착 상태가 새 인생에도 유지되며, 1회성 startingStat만 리셋.
export function consumeLoadoutForCharacter() {
  const m = ensureMeta();
  // 장착 유물의 레벨도 함께 넘김 — 캐릭터 효과 계산(traitEffects)에서 레벨 반영.
  const relicLevels = {};
  for (const k of m.loadout.relics) relicLevels[k] = m.permanentPurchases.relicLevels?.[k] ?? 1;
  const snapshot = {
    startingStat: m.loadout.startingStat,
    traits: [...m.loadout.traits],
    relics: [...m.loadout.relics],
    relicLevels,
    equipment: { ...(m.loadout.equipment ?? { bat: 0, glove: 0, cleats: 0 }) },
  };
  m.loadout.startingStat = null;
  saveRegressionMeta();
  return snapshot;
}

export function toggleEquipmentLoadout(type) {
  const m = ensureMeta();
  if (!m.loadout.equipment) {
    m.loadout.equipment = { bat: 0, glove: 0, cleats: 0 };
  }
  if (!m.permanentPurchases.equipment) {
    m.permanentPurchases.equipment = { bat: 0, glove: 0, cleats: 0 };
  }
  const curEquipped = m.loadout.equipment[type] ?? 0;
  const ownedMax = m.permanentPurchases.equipment[type] ?? 0;
  
  if (curEquipped > 0) {
    m.loadout.equipment[type] = 0;
  } else if (ownedMax > 0) {
    m.loadout.equipment[type] = ownedMax;
  }
  saveRegressionMeta();
  return true;
}


export function purchaseEquipment(type) {
  const m = ensureMeta();
  if (!m.permanentPurchases.equipment) {
    m.permanentPurchases.equipment = { bat: 0, glove: 0, cleats: 0 };
  }
  const currentLvl = m.permanentPurchases.equipment[type] ?? 0;
  const catalog = EQUIPMENT_CATALOG[type];
  if (!catalog) return { ok: false, reason: "invalid_type" };
  const nextItem = catalog.find(item => item.level === currentLvl + 1);
  if (!nextItem) return { ok: false, reason: "max_tier" };
  if (m.balance < nextItem.cost) return { ok: false, reason: "insufficient_balance" };

  m.balance -= nextItem.cost;
  m.permanentPurchases.equipment[type] = nextItem.level;
  saveRegressionMeta();
  return { ok: true, type, level: nextItem.level, cost: nextItem.cost };
}

export function recordHallOfFame(player) {
  const m = ensureMeta();
  if (!m.hallOfFameMuseum) {
    m.hallOfFameMuseum = { batter: null, pitcher: null, balanced: null, honor: null, tournament: null };
  }
  
  const scoreData = computeHallOfFameScore(player);
  const cs = player.careerStats ?? {};
  const ss = player.seasonStats ?? {};
  const combine = (k) => (cs[k] ?? 0) + (ss[k] ?? 0);
  
  // 5가지 분야별 가중치/점수 산출
  // 1) batter score
  const batterScore = combine("h") / 30 + combine("hr") / 3 + combine("rbi") / 50 + combine("sb") / 30;
  // 2) pitcher score
  const pitcherScore = combine("w") / 2 + combine("pK") / 10 + combine("sv") / 5;
  // 3) balanced score
  const bOVR = (player.batter.contact + player.batter.power + player.batter.eye + player.batter.speed + player.batter.defense) / 5;
  const pOVR = (player.pitcher.velocity + player.pitcher.control + player.pitcher.breaking + player.pitcher.stamina + player.pitcher.mental) / 5;
  const balancedScore = (bOVR + pOVR) - Math.abs(bOVR - pOVR) * 0.5;
  // 4) honor score
  const honorScore = scoreData.total;
  // 5) tournament wins
  const championshipsCount = player.championships?.length ?? 0;
  const tHistory = player.tournamentHistory ?? [];
  const tChampions = tHistory.filter(r => r.result === "champion").length;
  const tournamentWins = championshipsCount + tChampions;

  // 요약 보관 데이터 포맷
  const makeRecord = (categoryScore) => ({
    name: player.name,
    faceId: player.faceId,
    age: player.age,
    position: player.position,
    score: scoreData.total,
    rank: hofRank(scoreData.total),
    categoryScore: +categoryScore.toFixed(1),
    retiredYear: player.careerHistory?.[player.careerHistory.length - 1]?.year ?? new Date().getFullYear(),
    stats: {
      ab: combine("ab"),
      h: combine("h"),
      hr: combine("hr"),
      rbi: combine("rbi"),
      sb: combine("sb"),
      w: combine("w"),
      l: combine("l"),
      sv: combine("sv"),
      ipOuts: combine("ipOuts"),
      pK: combine("pK"),
      er: combine("er"),
      games: combine("games"),
      pitchG: combine("pitchG"),
    },
    awardsCount: player.awards?.length ?? 0,
    championshipsCount: championshipsCount
  });

  let updated = false;

  // 카테고리별 1위 판정 및 갱신
  const categories = [
    { key: "batter", score: batterScore },
    { key: "pitcher", score: pitcherScore },
    { key: "balanced", score: balancedScore },
    { key: "honor", score: honorScore },
    { key: "tournament", score: tournamentWins }
  ];

  for (const cat of categories) {
    const current = m.hallOfFameMuseum[cat.key];
    if (!current || cat.score > (current.categoryScore ?? 0)) {
      m.hallOfFameMuseum[cat.key] = makeRecord(cat.score);
      updated = true;
    }
  }

  if (updated) {
    saveRegressionMeta();
  }
  return updated;
}

export function deleteHallOfFameRecord(key) {
  const m = ensureMeta();
  if (m.hallOfFameMuseum && m.hallOfFameMuseum[key] !== undefined) {
    m.hallOfFameMuseum[key] = null;
    saveRegressionMeta();
    return true;
  }
  return false;
}

// 디버그/probe 용 — 전체 메타 초기화.
export function resetRegressionMeta() {
  state.regression = defaultRegressionMeta();
  saveRegressionMeta();
  return state.regression;
}


